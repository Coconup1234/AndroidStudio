package com.example.mywebviewer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mywebviewer.databinding.ActivityMainBinding;
import com.google.android.material.tabs.TabLayoutMediator;


public class MainActivity extends AppCompatActivity {



    ActivityMainBinding binding ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.viewPager.setAdapter(new ViewPagerAdapter(this));

        new TabLayoutMediator(binding.tabLayout,binding.viewPager,(tab, position) ->     {
            if(position == 0){
                tab.setText("경제");

            }
            else if(position == 1){
                tab.setText("연예");


            }else{
                tab.setText("강한쇠질");
            }
        }).attach();

    }
}