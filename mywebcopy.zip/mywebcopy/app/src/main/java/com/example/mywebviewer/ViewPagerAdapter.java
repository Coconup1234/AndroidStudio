package com.example.mywebviewer;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapter extends FragmentStateAdapter {
    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if(position==0){
//            AFragment aFragment = new AFragment();
//            return aFragment;
            WebViewFragment webViewFragment = new WebViewFragment("https://www.youtube.com/watch?v=hf7r-LjwWtc");
            return webViewFragment;
        }
        else if(position ==1){
//            BFragment bFragment = new BFragment();
//            return bFragment;
            WebViewFragment webViewFragment = new WebViewFragment("https://www.youtube.com/");
            return webViewFragment;
        }
        else{
//            CFragment cFragment = new CFragment();
//            return cFragment;
            WebViewFragment webViewFragment = new WebViewFragment("https://namu.wiki/w/%EC%8B%9C%ED%8B%B0%ED%98%84");
            return webViewFragment;
        }

    }

    @Override
    public int getItemCount() {
        return 3; //3개의 탭을 생성하기 떄문에 3
    }
}
